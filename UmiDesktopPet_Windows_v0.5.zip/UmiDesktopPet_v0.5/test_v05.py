import os
os.environ.setdefault('QT_QPA_PLATFORM', 'offscreen')
import json
import tempfile
import unittest
from unittest.mock import patch
from PySide6.QtCore import QSettings
from PySide6.QtWidgets import QApplication
from gacha import Collection
from gallery import Gallery
from dialogue import Dialogue, LINES
from main import Umi
from test_gacha import FixedRandom

app = QApplication.instance() or QApplication([])

class V05Tests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.settings = QSettings(self.temp.name+'/settings.ini', QSettings.Format.IniFormat)
    def tearDown(self): self.temp.cleanup()
    def model(self, values): return Collection(self.settings, FixedRandom(values))
    def test_white_pity_boundary_and_reset(self):
        c=self.model([1,1,1, 1,1,1,1])
        c.data['white_misses']=48
        self.assertEqual(c.roll()['bag'], 'none')
        r=c.roll()
        self.assertEqual(r['bag'], 'white')
        self.assertTrue(r['pity'])
        self.assertFalse(r['drops'][0]['shiny'])
        self.assertEqual(Collection(self.settings).data['white_misses'],0)
    def test_pity_off_and_natural_white_reset(self):
        c=self.model([1,1,1, 0,1,1,1])
        c.set_pity(0);c.data['white_misses']=100
        self.assertEqual(c.roll()['bag'],'none')
        self.assertFalse(c.roll()['pity'])
        self.assertEqual(c.data['white_misses'],0)
    def test_v04_migration_preserves_collection(self):
        c=Collection(self.settings)
        c.data['items']={'doom_bow':7};c.data['shiny']={'cdirk':2};c.data['tokens']=19
        old=dict(c.data);old.pop('white_misses');old.pop('pity_limit')
        self.settings.setValue('gacha_v1',json.dumps(old))
        new=Collection(self.settings)
        for key in old:self.assertEqual(new.data[key],old[key])
        self.assertEqual(new.data['white_misses'],0)
        self.assertEqual(new.data['pity_limit'],50)
    def test_save_failure_restores_roll_and_pity(self):
        c=self.model([1,1,1,1]);c.data['white_misses']=49
        before=json.loads(json.dumps(c.data))
        with patch.object(c,'save',side_effect=OSError('disk full')):
            with self.assertRaises(OSError):c.roll()
        self.assertEqual(c.data,before)
    def test_bag_reveal_is_single_charge_and_survives_reopen(self):
        c=self.model([0,1,1,1]);g=Gallery(c)
        g.roll();self.assertIsNotNone(g.pending)
        self.assertEqual(c.data['tokens'],4)
        g.roll();self.assertEqual(c.data['tokens'],4)
        restored=Gallery(Collection(self.settings))
        self.assertIn('Doom Bow',restored.result.text())
        g.reveal();g.reveal()
        self.assertIn('Doom Bow',g.result.text())
        self.assertEqual(c.data['tokens'],4)
        self.assertEqual(g.item_row.count(),1)
        g.close();restored.close()
    def test_dialogue_avoids_immediate_repeat(self):
        d=Dialogue()
        for context in LINES:
            previous=d.choose(context)
            for _ in range(30):
                current=d.choose(context);self.assertNotEqual(current,previous);previous=current
    def test_boss_native_frames_and_chatter_pause(self):
        pet=Umi();pet.timer.stop();pet.borrowed_attacks=False;pet.reduced_motion=False
        seen=set()
        for direction in ('right','up','down'):
            pet.walk_direction=direction;pet.state='wander';pet.walking=True
            for i in range(4):
                pet.walk_phase=i;frame,_,key=pet.skin_frame()
                seen.add(pet.boss_sequences[key][i]);self.assertFalse(frame.isNull())
        pet.state='rest';pet.walking=False
        frame,_,key=pet.skin_frame();seen.add(pet.boss_sequences[key][0])
        self.assertEqual(seen,set(range(13)))
        pet.events_enabled=False;pet.encounter=None;pet.chatter=True
        pet.next_chatter=pet.ticks;pet.message_until=0;pet.paused=True
        with patch.object(pet,'say') as say:
            pet.step();say.assert_not_called()
            pet.paused=False;pet.state='rest';pet.state_until=pet.ticks+100
            pet.step();say.assert_called_once()
        pet.close()

if __name__=='__main__':unittest.main()
