import os
os.environ.setdefault('QT_QPA_PLATFORM','offscreen')
import tempfile
import unittest
from PySide6.QtCore import QSettings
from gacha import Collection, DEFAULT_RATES, WHITE

class FixedRandom:
    def __init__(self, values): self.values=iter(values)
    def random(self): return next(self.values)
    def choice(self, items): return items[0]

class GachaTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory()
        self.settings=QSettings(self.temp.name+'/save.ini',QSettings.Format.IniFormat)
    def tearDown(self): self.temp.cleanup()
    def model(self,values): return Collection(self.settings,FixedRandom(values))
    def test_shiny_and_multiple_drops_persist(self):
        c=self.model([0,0,0,0]);r=c.roll()
        self.assertEqual(r['bag'],'white');self.assertEqual(len(r['drops']),3)
        self.assertTrue(r['drops'][0]['shiny'])
        restored=Collection(self.settings)
        self.assertEqual(restored.data['shiny']['doom_bow'],1)
        self.assertEqual(restored.data['tokens'],4)
        self.assertNotIn('doom_bow',restored.data['items'])
    def test_no_drop_and_no_tokens(self):
        c=self.model([.9,.9,.9]);self.assertEqual(c.roll()['bag'],'none')
        c.data['tokens']=0
        self.assertIsNone(c.roll());self.assertEqual(c.data['rolls'],1)
    def test_shiny_conditional_and_duplicate(self):
        c=self.model([0,0,1,1,0,0,1,1]);c.roll();r=c.roll()
        self.assertTrue(r['drops'][0]['duplicate']);self.assertEqual(c.data['shiny']['doom_bow'],2)
    def test_red_and_cyan_priority(self):
        c=self.model([1,0,0]);r=c.roll()
        self.assertEqual(r['bag'],'red');self.assertEqual(len(r['drops']),2)
        self.assertEqual(c.data['shiny'],{})
    def test_probability_boundaries(self):
        c=self.model([.03,.08,.20]);self.assertEqual(c.roll()['bag'],'none')
        rates=DEFAULT_RATES.copy();rates['white']=2
        with self.assertRaises(ValueError):c.set_rates(rates)
        self.assertEqual(c.data['rates'],DEFAULT_RATES)
    def test_corrupt_data_preserved(self):
        self.settings.setValue('gacha_v1','broken')
        with self.assertRaises(ValueError):Collection(self.settings)
        self.assertEqual(self.settings.value('gacha_v1'),'broken')

if __name__=='__main__':unittest.main()
