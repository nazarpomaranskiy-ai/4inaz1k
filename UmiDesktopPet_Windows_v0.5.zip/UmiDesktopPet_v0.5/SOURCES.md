# Sprite source and credits

Realm of the Mad God Exalt / Umi character artwork belongs to its respective
creators and DECA Games. This is an unofficial fan companion, not an official
DECA product. No ownership of the game artwork is claimed.

Public atlas mirror: https://github.com/liamt19/rotmg-dps-calculator-assets
Source revision: dd9f4082d2fb427d07b44fe27450c948ec27078b
- https://github.com/liamt19/rotmg-dps-calculator-assets/blob/dd9f4082d2fb427d07b44fe27450c948ec27078b/assets/characters.png
- https://github.com/liamt19/rotmg-dps-calculator-assets/blob/dd9f4082d2fb427d07b44fe27450c948ec27078b/assets/spritesheet.json

Selected metadata: moonlightVillageChars32x32, index 0, set 0.
Action 1, directions 0 (side), 2 (back), 3 (front): four frames each.
Action 0, direction 0: idle frame. Left is mirrored from the side frames.
Cells were extracted without redrawing and uniformly cropped from 32x32 to
17x16 using their common nontransparent bounds. The application uses integer
5x scaling without image smoothing. Frame timing is adapted for desktop travel;
it is not measured from gameplay footage. No video was downloaded or analyzed.

Original prototype sprite: provided by the user in UmiDesktopPet_Windows.zip.

## v0.4 Sorcerer replacement
The same revision's `playerskins32`, index 5, set 0 supplies the Sorcerer skin.
All 40 cells are retained at their original 32x32 origin in `sorcerer.png`.
`sorcerer.json` maps action:direction to frame indices: idle 0, walk 1,
fire spin 2, magic effect 4; directions side 0, back 2, front 3.
The older boss sprite assets remain for compatibility but are not rendered by
v0.4's companion. Fan-simulation drop percentages are local design choices;
no official server drop rates or game integration are claimed.

## v0.5 boss and original loot artwork
Boss extraction uses the same pinned atlas revision above:
`moonlightVillageChars32x32`, index 0, set 0, all 13 available entries.
`boss.json` maps native action/direction to aligned 32x32 cells in `boss.png`.
Only action 0 side idle (one frame) and action 1 side/back/front (four each)
exist for this selection. The optional Sorcerer attacks retain their original
skin appearance; they are borrowed frames, not newly discovered boss animations.
Default attacks use native boss movement frames plus procedural desktop effects.

Item and bag icons are unmodified crops of `mapObjects.png`, same pinned revision:
https://github.com/liamt19/rotmg-dps-calculator-assets/blob/dd9f4082d2fb427d07b44fe27450c948ec27078b/assets/mapObjects.png
Texture-name/index lookups were verified against the public game XML mirror:
https://static.drips.pw/rotmg/production/current/xmlc/Objects.xml
Retrieved 2026-11-06. This is a mutable metadata mirror, not bundled game files
from the user's computer. Per-icon texture indices and exact atlas rectangles
are recorded in `assets/icons.json`. Base item artwork is also used when a local
simulation marks the acquisition shiny; no distinct shiny artwork is claimed.
Loot Bag 6 = white (`lofiObj4` 0xd9), Loot Bag 9 = red (0xd8),
Loot Bag 5 = cyan (0xd6). All images scale with nearest-neighbor filtering.
Dialogue text is original to this companion. The pity mechanic is a local design
choice, not an official RotMG rule.
