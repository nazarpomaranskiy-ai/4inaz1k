"""Local fan drop simulation. Probabilities are not official RotMG rates."""
import copy
import json
import random
from PySide6.QtCore import QSettings

WHITE = [('doom_bow', 'Doom Bow'), ('cdirk', 'Dirk of Cronus'),
         ('conflict', 'Orb of Conflict'), ('ogmur', 'Shield of Ogmur'),
         ('oreo', 'Seal of Blasphemous Prayer'), ('dblade', 'Demon Blade')]
POOLS = {'white': WHITE, 'cyan': [('wand', 'Wand of Recompense'), ('robe', 'Robe of the Grand Sorcerer'),
                                ('ring', 'Ring of Unbound Health')],
         'red': [('katana', 'Kusanagi'), ('staff', 'Staff of the Fundamental Core'), ('armor', 'Leviathan Armor')]}
DEFAULT_RATES = {'white': .03, 'red': .08, 'cyan': .20, 'shiny': .02}

class Collection:
    def __init__(self, settings=None, rng=None):
        self.settings = settings or QSettings('UmiDesktop', 'Companion')
        self.rng = rng or random.Random()
        raw = self.settings.value('gacha_v1', '')
        self.data = json.loads(raw) if raw else {'version': 1, 'tokens': 5, 'rolls': 0,
                     'items': {}, 'shiny': {}, 'history': [], 'rates': DEFAULT_RATES.copy()}
        self.data.setdefault('white_misses', 0)
        self.data.setdefault('pity_limit', 50)
        self.validate()

    def validate(self):
        d = self.data
        if d.get('version') != 1: raise ValueError('Unsupported collection version')
        for key in ('tokens', 'rolls', 'white_misses', 'pity_limit'):
            if type(d.get(key)) is not int or d[key] < 0: raise ValueError('Invalid collection counter')
        for key in ('items', 'shiny'):
            if not isinstance(d.get(key), dict) or any(type(v) is not int or v < 0 for v in d[key].values()):
                raise ValueError('Invalid collection inventory')
        if not isinstance(d.get('history'), list): raise ValueError('Invalid history')
        for key in DEFAULT_RATES:
            v = d['rates'][key]
            if not isinstance(v, (int, float)) or not 0 <= v <= 1: raise ValueError('Invalid probability')

    def save(self):
        self.validate()
        self.settings.setValue('gacha_v1', json.dumps(self.data, ensure_ascii=False))
        self.settings.sync()
        if self.settings.status() != QSettings.Status.NoError:
            raise OSError('Не вдалося зберегти колекцію')

    def grant(self, count=1):
        if type(count) is not int or count < 0: raise ValueError('Invalid token grant')
        previous = self.data['tokens']
        self.data['tokens'] += count
        try: self.save()
        except Exception:
            self.data['tokens'] = previous
            raise

    def set_rates(self, rates):
        previous = self.data['rates']
        self.data['rates'] = rates.copy()
        try: self.save()
        except Exception:
            self.data['rates'] = previous
            raise

    def set_pity(self, limit):
        if type(limit) is not int or not 0 <= limit <= 500: raise ValueError('Invalid pity limit')
        previous = self.data['pity_limit']
        self.data['pity_limit'] = limit
        try: self.save()
        except Exception:
            self.data['pity_limit'] = previous
            raise

    def roll(self):
        if self.data['tokens'] <= 0: return None
        before = copy.deepcopy(self.data)
        try:
            d = self.data
            d['tokens'] -= 1
            d['rolls'] += 1
            drops = []
            # Independent pools; the displayed bag is the highest rarity rolled.
            pity = bool(d['pity_limit'] and d['white_misses'] >= d['pity_limit']-1)
            for bag in ('white', 'red', 'cyan'):
                success = self.rng.random() < d['rates'][bag]
                if success or (bag == 'white' and pity):
                    item_id, name = self.rng.choice(POOLS[bag])
                    shiny = bag == 'white' and self.rng.random() < d['rates']['shiny']
                    target = d['shiny'] if shiny else d['items']
                    duplicate = target.get(item_id, 0) > 0
                    target[item_id] = target.get(item_id, 0)+1
                    drops.append({'id': item_id, 'name': name, 'bag': bag,
                                  'shiny': shiny, 'duplicate': duplicate})
            d['white_misses'] = 0 if any(x['bag']=='white' for x in drops) else d['white_misses']+1
            result = {'pity': pity, 'bag': drops[0]['bag'] if drops else 'none', 'drops': drops}
            d['history'] = (d['history'] + [result])[-30:]
            self.save()
            return result
        except Exception:
            self.data = before
            raise
