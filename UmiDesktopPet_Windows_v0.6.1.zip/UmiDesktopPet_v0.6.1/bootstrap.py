"""Stdlib-only entry point: record import, launch and Qt callback failures."""
import faulthandler
import logging
from pathlib import Path
import runpy
import sys

ROOT = Path(__file__).resolve().parent

def install_diagnostics(root=ROOT):
    log = root / 'umi-error.log'
    # Append so a second launch cannot erase the first failure.
    handler = logging.FileHandler(log, encoding='utf-8')
    handler.setFormatter(logging.Formatter('%(asctime)s %(levelname)s %(message)s'))
    logger = logging.getLogger('umi')
    logger.setLevel(logging.INFO)
    logger.addHandler(handler)
    logger.info('Umi 0.6.1 / Python %s / platform %s / safe=%s', sys.version.split()[0], sys.platform, '--safe' in sys.argv)
    fault = log.open('a', encoding='utf-8')
    faulthandler.enable(file=fault)
    old_hook = sys.excepthook
    def hook(kind, value, trace):
        logger.error('Unhandled exception', exc_info=(kind,value,trace))
        old_hook(kind,value,trace)
    sys.excepthook = hook
    return logger, fault

def main():
    logger, fault = install_diagnostics()
    try:
        sys.path.insert(0,str(ROOT))
        runpy.run_path(str(ROOT / 'main.py'), run_name='__main__')
    except SystemExit:
        raise
    except Exception:
        logger.exception('Startup failed')
        print('Umi could not start. See umi-error.log for the full traceback.',file=sys.stderr)
        import traceback
        traceback.print_exc()
        return 1
    finally:
        faulthandler.disable()
        fault.close()
    return 0

if __name__=='__main__': sys.exit(main())
