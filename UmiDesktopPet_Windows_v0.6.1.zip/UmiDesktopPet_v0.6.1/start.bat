@echo off
setlocal
cd /d "%~dp0"
set "UMI_LOG=%~dp0startup.log"
> "%UMI_LOG%" echo Umi 0.6.1 startup
if not exist bootstrap.py goto missing_files
if not exist main.py goto missing_files
if not exist assets\boss.png goto missing_files
if exist ".venv-061\Scripts\python.exe" goto dependencies
set "UMI_PY="
for %%V in (3.13 3.12 3.11 3.10) do call :try_py %%V
if defined UMI_PY goto create_env
python -c "import sys,struct; sys.exit(0 if (3,10) <= sys.version_info[:2] < (3,14) and struct.calcsize('P') == 8 else 1)" >nul 2>>"%UMI_LOG%"
if errorlevel 1 goto no_python
set "UMI_PY=python"
:create_env
echo Creating Python environment. Please wait...
%UMI_PY% -m venv ".venv-061" >>"%UMI_LOG%" 2>&1
if errorlevel 1 goto failed
:dependencies
echo Checking dependencies...
".venv-061\Scripts\python.exe" -c "from PySide6.QtWidgets import QApplication" >>"%UMI_LOG%" 2>&1
if not errorlevel 1 goto run_pet
echo Installing PySide6. First launch requires Internet and may take a few minutes.
".venv-061\Scripts\python.exe" -m pip install -r requirements.txt >>"%UMI_LOG%" 2>&1
if errorlevel 1 goto failed
:run_pet
echo Starting Umi. Keep this window open while Umi is running.
echo If Umi is hidden, use the Umi icon near the Windows clock.
".venv-061\Scripts\python.exe" -u bootstrap.py %* >>"%UMI_LOG%" 2>&1
if errorlevel 1 goto failed
exit /b 0
:try_py
if defined UMI_PY exit /b 0
py -%1 -c "import struct,sys; sys.exit(0 if struct.calcsize('P') == 8 else 1)" >nul 2>>"%UMI_LOG%"
if errorlevel 1 exit /b 0
set "UMI_PY=py -%1"
exit /b 0
:missing_files
echo Extract the ENTIRE ZIP into a regular folder first.
echo Run start.bat from that folder, not from inside the ZIP.
echo Missing main.py, bootstrap.py or assets\boss.png.
goto failed
:no_python
echo Python 3.10-3.13 64-bit was not found.
echo Install Python 3.12 64-bit from https://www.python.org/downloads/windows/
echo Enable the Python launcher and Add Python to PATH, then run start.bat again.
goto failed
:failed
echo.
echo Umi could not start. Details below:
type "%UMI_LOG%"
echo.
echo Send startup.log and umi-error.log from this folder if the issue continues.
pause
exit /b 1
