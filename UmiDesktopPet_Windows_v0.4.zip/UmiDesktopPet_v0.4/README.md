# Umi Desktop Pet v0.4 — Kitsune Umi Sorcerer

## Windows installation
Close the previous Umi, extract this archive into a new folder and run `start.bat`.
Requires Python 3.10+ with the `py` launcher. First launch installs PySide6 into
`.venv`; subsequent launches reuse it. This is Python source, not a compiled EXE.
Settings and collection survive upgrades via per-user Qt settings.

## Skin and controls
The companion now renders the Kitsune Umi Sorcerer skin from the public game
atlas (`playerskins32`, index 5), including all 40 available cells:
- idle: four frames each for side/front/back;
- walking: four frames each for side/front/back;
- shooting: four native fire-spin frames (side, mirrored for left);
- magic: four frames each for side/front/back.

Right-click Umi for Shoot / fire spin, Magic, direction selection, walking,
dancing, sleeping, events, pause, reduced motion, and **Gacha & Shiny Gallery**.
Shooting also plays in slime encounters. Magic and shooting can occur while idle.
Left click pets Umi, drag moves her, double click dances. All character states
use the new skin; jumps/dances additionally use procedural transformations.
Animation timing is adapted for the desktop, not a frame-perfect gameplay replay.
Reduced motion freezes sprite animation and decorative motion. Pause freezes
the pet simulation; the collection window remains usable.

## Gacha
Five free attempts on first use. Click a gold token after the slime fight or
in the loot event to earn one attempt. These replace the previous guaranteed
white-bag collectible. Manual events can also earn tokens; this is a local toy.
Open the collection window through the right-click menu to spend attempts.
No payments, real game drops, account connection or pity system.

Each attempt independently rolls three pools; multiple pools can succeed.
The visible bag is the highest rolled pool: white > red > cyan. A failed attempt
consumes one token. Each successful pool chooses one item uniformly.

**These are configurable fan-simulation rates, NOT official RotMG probabilities:**
- White pool: 3% per attempt.
- Red pool: 8% per attempt (high-tier equipment).
- Cyan pool: 20% per attempt.
- Shiny: 2% conditional on a white drop, replacing the normal item.
- Any shiny: 0.06% per attempt with defaults; any specific shiny: 0.01%.
- Empty attempt: 71.392% with defaults.

Change rates in the Odds tab. Its percentages refer to independent pool rolls,
not mutually exclusive displayed-bag odds. Defaults can be restored there.
This is a selected, illustrative pool, not a full game loot-table simulation.

## Shiny Gallery
Six named white collectibles: Doom Bow, Dirk of Cronus, Orb of Conflict,
Shield of Ogmur, Seal of Blasphemous Prayer, Demon Blade.
The text-card gallery shows locked/unlocked status, number of copies, duplicates,
and completion percentage. Item artwork and the full game shiny catalog are not
included. Only a shiny acquisition advances shiny completion; normal copies do
not. Collection, attempts, rates, counts and last 30 results are saved immediately
in `gacha_v1` under Qt's `UmiDesktop/Companion` user settings (Windows registry).
The previous v0.3 loot counter is preserved separately, not converted to shinies.
Malformed collection data is reported without silently wiping the saved value.

## Validation and limitations
Run `python -m unittest -v test_pet test_gacha` for 14 offscreen Qt/model tests.
Tests cover all 40 animation cells, movement, events, pauses, drop outcomes,
conditional shiny rolls, duplicates, empty balance, probability boundaries,
and persistence. Native Windows transparency/DPI and batch startup still need
Windows verification. The pet has a rectangular 240x230 mouse interaction area.
Drag it away when it overlaps another application. No other windows are modified.
See SOURCES.md for the original atlas source and artwork attribution.
