import os
os.environ.setdefault('QT_QPA_PLATFORM', 'offscreen')
import unittest
from PySide6.QtCore import QPoint, Qt, QSettings
from PySide6.QtTest import QTest
from PySide6.QtWidgets import QApplication
from main import Umi, EVENTS

app = QApplication.instance() or QApplication([])
QSettings.setDefaultFormat(QSettings.Format.IniFormat)
QSettings.setPath(QSettings.Format.NativeFormat, QSettings.Scope.UserScope, '/tmp/umi-test-settings')

class PetTests(unittest.TestCase):
    def setUp(self):
        self.pet = Umi()
        self.pet.timer.stop()
        self.pet.events_enabled = False
        self.pet.reduced_motion = False
    def tearDown(self):
        self.pet.close()
    def test_all_states_render(self):
        for state in ['wander', 'chase', 'dance', 'sleep', 'hop', 'happy', 'look', 'shoot', 'cast']:
            self.pet.animate(state)
            self.pet.step()
            self.assertFalse(self.pet.grab().isNull())
        for kind in EVENTS:
            self.pet.trigger_event(kind)
            self.pet.step()
            self.assertFalse(self.pet.grab().isNull())
    def test_slime_drops_collectible_loot(self):
        self.pet.trigger_event('slime')
        for _ in range(150): self.pet.step()
        self.assertEqual(self.pet.encounter, 'loot')
        count = self.pet.loot_count
        QTest.mouseClick(self.pet, Qt.MouseButton.LeftButton, pos=QPoint(188, 153))
        self.assertEqual(self.pet.loot_count, count+1)
        self.assertIsNone(self.pet.encounter)
    def test_pause_freezes_event(self):
        self.pet.trigger_event('meteor')
        self.pet.paused = True
        before = (self.pet.ticks, self.pet.event_age)
        for _ in range(30): self.pet.step()
        self.assertEqual(before, (self.pet.ticks, self.pet.event_age))
    def test_reduced_motion_and_expiry(self):
        self.pet.reduced_motion = True
        self.pet.animate('wander')
        before = self.pet.pos()
        for _ in range(40): self.pet.step()
        self.assertEqual(self.pet.pos(), before)
        self.pet.trigger_event('portal')
        for _ in range(240): self.pet.step()
        self.assertIsNone(self.pet.encounter)
    def test_pet_and_drag(self):
        QTest.mouseClick(self.pet, Qt.MouseButton.LeftButton, pos=QPoint(100, 120))
        self.assertEqual(self.pet.state, 'happy')
        QTest.mousePress(self.pet, Qt.MouseButton.LeftButton, pos=QPoint(100, 120))
        QTest.mouseMove(self.pet, QPoint(130, 140))
        QTest.mouseRelease(self.pet, Qt.MouseButton.LeftButton, pos=QPoint(130, 140))
        self.assertIsNone(self.pet.drag_offset)
        self.assertEqual(self.pet.state, 'hop')
    def test_real_walk_frames_and_directions(self):
        self.pet.animate('wander', 1000)
        self.pet.xpos, self.pet.ypos = 200., 200.
        self.pet.dx, self.pet.dy = 2., 0.
        seen = set()
        for _ in range(30):
            self.pet.step()
            seen.add(int(self.pet.walk_phase))
        self.assertEqual(seen, {0, 1, 2, 3})
        self.assertEqual(self.pet.walk_direction, 'right')
        frames = [self.pet.walk_frames[i].toImage() for i in self.pet.walk_sequences['right']]
        self.assertTrue(any(f != frames[0] for f in frames[1:]))
        self.pet.dx, self.pet.dy = 0., -2.
        self.pet.step()
        self.assertEqual(self.pet.walk_direction, 'up')
        self.pet.dx, self.pet.dy = 0., 2.
        self.pet.step()
        self.assertEqual(self.pet.walk_direction, 'down')
        self.pet.dx, self.pet.dy = -2., 0.
        self.pet.step()
        self.assertEqual(self.pet.facing, -1)
        self.pet.dx = self.pet.dy = 0.
        self.pet.step()
        self.assertFalse(self.pet.walking)
        self.assertEqual(self.pet.walk_phase, 0.)

    def test_all_skin_frames_reachable(self):
        seen=set()
        for direction in ('right','up','down'):
            self.pet.walk_direction=direction
            for state in ('rest','wander','cast','shoot'):
                self.pet.state=state
                self.pet.walking=state=='wander'
                for i in range(4):
                    self.pet.ticks=i*5
                    self.pet.walk_phase=float(i)
                    frame,_,key=self.pet.skin_frame()
                    seen.add(self.pet.skin_sequences[key][i])
                    self.assertFalse(frame.isNull())
                    self.assertFalse(self.pet.grab().isNull())
        self.assertEqual(seen,set(range(40)))

    def test_automatic_event(self):
        self.pet.events_enabled = True
        self.pet.next_event = self.pet.ticks+1
        self.pet.step()
        self.assertIn(self.pet.encounter, EVENTS)

if __name__ == '__main__': unittest.main()
