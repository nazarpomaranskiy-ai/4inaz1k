from PySide6.QtCore import Qt
from PySide6.QtWidgets import (QDialog, QVBoxLayout, QHBoxLayout, QLabel, QPushButton,
    QProgressBar, QTabWidget, QWidget, QGridLayout, QDoubleSpinBox, QFormLayout, QMessageBox)
from gacha import WHITE, DEFAULT_RATES

class Gallery(QDialog):
    def __init__(self, collection, parent=None):
        super().__init__(parent)
        self.collection = collection
        self.setWindowTitle('Umi • Gacha & Shiny Gallery')
        self.resize(620, 580)
        self.setStyleSheet('''QDialog, QWidget {background:#191626;color:#eee8ff;font-size:13px;}
          QPushButton {background:#6543aa;padding:10px;border-radius:6px;}
          QPushButton:disabled {background:#393345;color:#888;}
          QTabBar::tab {padding:10px;} QProgressBar {border:1px solid #77628d;}
          QProgressBar::chunk {background:#b798f3;} QDoubleSpinBox {padding:6px;}''')
        layout = QVBoxLayout(self)
        self.balance = QLabel();layout.addWidget(self.balance)
        tabs = QTabWidget();layout.addWidget(tabs)
        summon = QWidget();sl = QVBoxLayout(summon)
        sl.addWidget(QLabel('Одна спроба = незалежні перевірки white, red та cyan.\n'
                            'Мішок показує найвищу рідкість; можна отримати кілька предметів.'))
        self.result = QLabel('П’ять стартових спроб. Нові спроби — за івенти Umi.')
        self.result.setWordWrap(True);self.result.setMinimumHeight(145);sl.addWidget(self.result)
        self.roll_button = QPushButton('Відкрити дроп • 1 спроба')
        self.roll_button.clicked.connect(self.roll);sl.addWidget(self.roll_button)
        self.history = QLabel();self.history.setWordWrap(True);sl.addWidget(self.history)
        sl.addStretch();tabs.addTab(summon,'Гача')
        gallery = QWidget();gl=QVBoxLayout(gallery)
        gl.addWidget(QLabel('Shiny Whites • стартова колекція з 6 предметів'))
        self.progress = QProgressBar();self.progress.setRange(0,len(WHITE));gl.addWidget(self.progress)
        grid=QGridLayout();self.cards={}
        for i,(item_id,name) in enumerate(WHITE):
            card=QLabel();card.setWordWrap(True);card.setMinimumHeight(85)
            card.setAlignment(Qt.AlignmentFlag.AlignCenter)
            self.cards[item_id]=card;grid.addWidget(card,i//2,i%2)
        gl.addLayout(grid);tabs.addTab(gallery,'Shiny Gallery')
        odds=QWidget();form=QFormLayout(odds)
        note=QLabel('Фанатська симуляція: це НЕ офіційні шанси RotMG.\n'
                    'Shiny — окремий рол після white; він замінює звичайний предмет.\n'
                    'Без pity, платежів і зв’язку з ігровим акаунтом.')
        note.setWordWrap(True);form.addRow(note);self.inputs={}
        for key,label in [('white','White pool, %'),('red','Red pool, %'),('cyan','Cyan pool, %'),('shiny','Shiny за умови white, %')]:
            spin=QDoubleSpinBox();spin.setRange(0,100);spin.setDecimals(2)
            spin.setValue(collection.data['rates'][key]*100);self.inputs[key]=spin;form.addRow(label,spin)
        save=QPushButton('Зберегти шанси');save.clicked.connect(self.save_rates);form.addRow(save)
        reset=QPushButton('Стандартні шанси');reset.clicked.connect(self.reset_rates);form.addRow(reset)
        self.odds=QLabel();self.odds.setWordWrap(True);form.addRow(self.odds)
        tabs.addTab(odds,'Шанси');self.refresh()

    def refresh(self):
        d=self.collection.data
        self.balance.setText(f'Спроби: {d["tokens"]}    •    Відкрито: {d["rolls"]}')
        self.roll_button.setEnabled(d['tokens'] > 0)
        count=sum(d['shiny'].get(k,0)>0 for k,_ in WHITE)
        self.progress.setValue(count);self.progress.setFormat(f'{count} / {len(WHITE)} shiny • %p%')
        for item_id,name in WHITE:
            n=d['shiny'].get(item_id,0)
            self.cards[item_id].setText(f'{"✦ SHINY" if n else "◇ Не знайдено"}\n{name}\n'+(f'Копій: {n} • дублікатів: {n-1}' if n else 'Збери shiny-версію з white pool'))
            self.cards[item_id].setStyleSheet('border:1px solid '+('#e9c878' if n else '#51465f')+';border-radius:8px;padding:8px;')
        r=d['rates'];self.odds.setText(f'Шанс будь-якого shiny за спробу: {r["white"]*r["shiny"]*100:.4f}%.\n'
            f'Порожній дроп: {(1-r["white"])*(1-r["red"])*(1-r["cyan"])*100:.2f}%.\n'
            'У межах кожного пулу предмети рівноймовірні.')
        self.history.setText('Останні мішки: '+ ' · '.join(x['bag'].upper() for x in d['history'][-8:]))

    def roll(self):
        try:
            result=self.collection.roll()
            if result is None:return
            lines=[result['bag'].upper()+' BAG' if result['drops'] else 'Цього разу без рідкісного дропу']
            for drop in result['drops']:
                lines.append(('✦ SHINY ' if drop['shiny'] else '')+drop['name']+(' • дублікат' if drop['duplicate'] else ' • новий!'))
            self.result.setText('\n'.join(lines))
            self.result.setStyleSheet('color:'+{'white':'#fff4ce','red':'#ff8397','cyan':'#78e8f5','none':'#aaa1bb'}[result['bag']]+';font-size:18px;')
            self.refresh()
        except (OSError,ValueError) as exc: QMessageBox.warning(self,'Збереження',str(exc))

    def save_rates(self):
        try:
            self.collection.set_rates({k:s.value()/100 for k,s in self.inputs.items()});self.refresh()
        except (OSError,ValueError) as exc: QMessageBox.warning(self,'Шанси',str(exc))

    def reset_rates(self):
        for k,v in DEFAULT_RATES.items():self.inputs[k].setValue(v*100)
        self.save_rates()
