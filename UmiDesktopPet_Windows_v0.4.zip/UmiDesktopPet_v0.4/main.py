"""Umi 0.4 — Sorcerer skin, native animation sequences, and local gacha collection."""
import json
from pathlib import Path
import math
import random
import sys
from PySide6.QtCore import QRect, Qt, QSettings
from PySide6.QtGui import QColor, QPainter, QFont, QPixmap
from PySide6.QtWidgets import QApplication, QMenu, QMessageBox
from base_pet import Umi as BasePet
from gacha import Collection
from gallery import Gallery

EVENTS = {'portal': 'Портал у Nexus!', 'slime': 'Слиз атакує!',
          'meteor': 'Зорепад!', 'loot': 'Гача-жетон! Натисни, щоб забрати'}

class Umi(BasePet):
    def __init__(self):
        self.settings = QSettings('UmiDesktop', 'Companion')
        self.collection = Collection(self.settings)
        self.gallery = None
        self.encounter = None
        self.event_age = 0
        self.next_event = random.randint(600, 1200)
        self.events_enabled = self.settings.value('events', True, type=bool)
        self.loot_count = self.settings.value('loot', 0, type=int)
        self.message = ''
        self.message_until = 0
        self.press_pos = None
        self.dragged = False
        self.hover_ticks = 0
        self.walk_phase = 0.0
        self.walking = False
        self.walk_direction = 'right'
        root = Path(__file__).resolve().parent / 'assets'
        self.skin_sequences = json.loads((root / 'sorcerer.json').read_text())
        sheet = QPixmap(str(root / 'sorcerer.png'))
        if sheet.isNull():
            raise RuntimeError('Missing assets/sorcerer.png')
        self.skin_frames = [sheet.copy(i*32, 0, 32, 32) for i in range(sheet.width()//32)]
        self.walk_frames = self.skin_frames
        self.walk_sequences = {k: self.skin_sequences['1:'+v]
                               for k,v in [('right','0'),('up','2'),('down','3')]}
        self.walk_idle = self.skin_sequences['0:0'][0]
        super().__init__()
        self.setFixedSize(240, 230)
        self.reduced_motion = self.settings.value('reduced', False, type=bool)
        self.say('Привіт! Погладь мене ♡', 150)
        self.clamp_position()

    def say(self, text, duration=100):
        self.message, self.message_until = text, self.ticks + duration
        self.update()

    def animate(self, state, duration=120):
        self.teleport_phase = 0
        self.state, self.state_until = state, self.ticks + duration
        self.update()

    def clamp_position(self):
        screen = QApplication.screenAt(self.frameGeometry().center()) or QApplication.primaryScreen()
        self.area = screen.availableGeometry()
        self.xpos = min(max(self.xpos, self.area.left()), max(self.area.left(), self.area.right()-self.width()+1))
        self.ypos = min(max(self.ypos, self.area.top()), max(self.area.top(), self.area.bottom()-self.height()+1))
        self.move(round(self.xpos), round(self.ypos))

    def pick_state(self):
        if self.encounter:
            return
        state = random.choice(['wander', 'wander', 'chase', 'dance', 'hop', 'sleep', 'look', 'shoot', 'cast'])
        if state in ('wander', 'chase', 'dance'):
            self.animate(state, random.randint(90, 180))
            self.dx = random.choice([-1, 1])*random.uniform(1, 2.7)
            self.dy = random.uniform(-1.5, 1.5)
            if self.reduced_motion:
                self.state = 'rest'
        else:
            self.animate(state, random.randint(90, 200))

    def trigger_event(self, kind=None):
        if self.paused:
            return
        self.encounter = kind or random.choice(list(EVENTS))
        self.event_age = 0
        self.animate('event', 300)
        self.say(EVENTS[self.encounter], 210)
        self.sparkle(12)

    def finish_event(self):
        self.encounter = None
        self.next_event = self.ticks + random.randint(600, 1350)
        self.animate('dance', 70)

    def collect_loot(self):
        if self.paused:
            return
        if self.encounter != 'loot':
            return
        try:
            self.collection.grant()
        except (OSError, ValueError) as exc:
            QMessageBox.warning(self, 'Збереження', str(exc))
            return
        self.loot_count += 1
        self.settings.setValue('loot', self.loot_count)
        self.finish_event()
        self.say('Гача: +1 спроба! Відкрий галерею через меню.', 120)
        self.sparkle(20)
        if self.gallery:
            self.gallery.refresh()

    def open_gallery(self):
        if self.gallery is None:
            self.gallery = Gallery(self.collection, self)
        self.gallery.refresh()
        self.gallery.show()
        self.gallery.raise_()
        self.gallery.activateWindow()

    def skin_frame(self):
        direction = {'right':'0', 'up':'2', 'down':'3'}[self.walk_direction]
        if self.state == 'shoot' or self.encounter == 'slime':
            key = '2:0'  # The skin's native four-frame fire spin.
        elif self.state == 'cast':
            key = '4:'+direction
        elif self.walking and self.state in ('wander','chase'):
            key = '1:'+direction
        else:
            key = '0:'+direction
        frames = self.skin_sequences[key]
        phase = self.walk_phase if key.startswith('1:') else self.ticks/5
        index = 0 if self.reduced_motion else int(phase) % len(frames)
        return self.skin_frames[frames[index]], direction, key

    def step(self):
        if self.paused or self.drag_offset is not None:
            return
        # Reduced motion freezes automatic travel as well as decorative transforms.
        if self.reduced_motion and self.state in ('wander', 'chase', 'teleport'):
            self.teleport_phase = 0
            self.animate('rest', 120)
        old_x, old_y = self.xpos, self.ypos
        super().step()
        vx, vy = self.xpos-old_x, self.ypos-old_y
        speed = math.hypot(vx, vy)
        self.walking = (self.state in ('wander', 'chase') and speed > .15
                        and not self.reduced_motion and not self.teleport_phase)
        if self.walking:
            self.walk_direction = ('down' if vy > 0 else 'up') if abs(vy) > abs(vx)*1.3 else 'right'
            if self.walk_direction == 'right':
                self.facing = 1 if vx >= 0 else -1
            self.walk_phase = (self.walk_phase + min(speed, 4)*.075) % 4
        else:
            self.walk_phase = 0.0
        if self.encounter:
            self.event_age += 1
            if self.encounter == 'slime' and self.event_age == 150:
                self.encounter, self.event_age = 'loot', 0
                self.say(EVENTS['loot'], 230)
                self.sparkle(20)
            elif self.event_age >= 240:
                self.finish_event()
        elif self.events_enabled and self.ticks >= self.next_event:
            self.trigger_event()
        if self.underMouse() and self.state == 'sleep':
            self.animate('look', 90)
            self.say('Мм? Уже ранок?')
        self.update()

    def paintEvent(self, event):
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.SmoothPixmapTransform, False)
        t = self.ticks
        motion = not self.reduced_motion
        bob = math.sin(t*.16)*2 if motion else 0
        angle, sx, sy = 0, 1, 1
        if motion:
            if self.state in ('wander', 'chase'):
                bob, angle = 0, 0
            elif self.state == 'dance':
                angle, bob = math.sin(t*.25)*13, -abs(math.sin(t*.25))*9
                sx = 1 + .07*math.sin(t*.5)
            elif self.state == 'hop':
                bob = -abs(math.sin(t*.17))*26
                sy = 1+.1*math.cos(t*.34)
            elif self.state == 'sleep':
                angle, sy = 12, .85+.025*math.sin(t*.07)
            elif self.state == 'happy':
                bob, angle = -abs(math.sin(t*.3))*12, math.sin(t*.2)*8
        p.setPen(Qt.PenStyle.NoPen)
        p.setBrush(QColor(40, 24, 57, 65))
        p.drawEllipse(68, 169, 74, 10)
        if self.encounter == 'portal':
            for r in range(36, 6, -6):
                p.setPen(QColor(120+r*3, 90, 230, 180))
                p.setBrush(Qt.BrushStyle.NoBrush)
                p.drawEllipse(105-r, 166-r//3, r*2, r*2//3)
        p.save()
        p.translate(105, 124+bob)
        p.rotate(angle)
        frame, direction, animation = self.skin_frame()
        facing = self.facing if direction == '0' or animation == '2:0' else 1
        p.scale(facing*sx, sy)
        if self.teleport_phase:
            p.setOpacity(max(.1, abs(self.teleport_phase-10)/10))
        # Keep all 32x32 cells aligned, including overhead spell effects.
        p.drawPixmap(QRect(-96, -147, 192, 192), frame)
        p.restore()
        p.setFont(QFont('Segoe UI', 11, QFont.Weight.Bold))
        p.setPen(QColor('#ffe3a1'))
        if self.state == 'sleep':
            p.drawText(155, 95, 'z Z' if t//30 % 2 else 'Z z')
        if self.state == 'happy':
            p.setPen(QColor('#ff91ba'))
            p.drawText(154, 100+round(bob), '♥')
        age = self.event_age if motion else 50
        if self.encounter == 'slime':
            offset = round(math.sin(age*.17)*4) if motion else 0
            p.fillRect(173, 143+offset, 30, 23, QColor('#7eda73'))
            p.fillRect(179, 137+offset, 18, 6, QColor('#b0f38c'))
            for x in (179, 191):
                p.fillRect(x, 149+offset, 4, 4, QColor('#263855'))
            p.fillRect(171, 128, max(0, round(34*(1-self.event_age/150))), 4, QColor('#ff7285'))
            for i in range(3):
                x = 132 + ((age*3+i*23) % 46)
                p.fillRect(x, 144+i*7, 5, 5, QColor('#b7a0ff'))
        elif self.encounter == 'loot':
            p.setBrush(QColor('#e2b65d'))
            p.setPen(QColor('#fff1a3'))
            p.drawEllipse(175, 139, 26, 28)
            p.setPen(QColor('#fff1a3'))
            p.drawText(182, 128, '✦')
        elif self.encounter == 'meteor':
            for i in range(8):
                y = (age*3+i*27) % 150 + 48
                x = (i*31+age) % 210+8
                p.fillRect(x, y, 4, 8, QColor('#ffcf81'))
                p.fillRect(x+2, y-9, 2, 9, QColor('#ba95eb'))
        if self.state == 'shoot':
            for i in range(3):
                travel = ((self.ticks*4+i*22) % 80) if motion else i*20
                p.fillRect(130+travel, 139+i*5, 5, 3, QColor('#ffbc69'))
        for x, y, _, _, life in (self.particles if motion else []):
            p.fillRect(round(x+25), round(y+40), 3, 3, QColor(255, 200, 120, min(255, life*9)))
        if self.ticks < self.message_until:
            p.setPen(QColor('#ecdffb'))
            p.setBrush(QColor(30, 24, 47, 235))
            p.drawRoundedRect(5, 6, 230, 55, 10, 10)
            p.setFont(QFont('Segoe UI', 9))
            p.drawText(QRect(12, 9, 216, 49), Qt.AlignmentFlag.AlignCenter | Qt.TextFlag.TextWordWrap, self.message)
        p.end()

    def mousePressEvent(self, event):
        if event.button() == Qt.MouseButton.LeftButton:
            if self.encounter == 'loot' and QRect(165, 125, 48, 55).contains(event.position().toPoint()):
                self.collect_loot()
                return
            self.press_pos = event.globalPosition().toPoint()
            self.dragged = False
        super().mousePressEvent(event)

    def mouseMoveEvent(self, event):
        if self.press_pos is not None and (event.globalPosition().toPoint()-self.press_pos).manhattanLength() > 8:
            self.dragged = True
        super().mouseMoveEvent(event)

    def mouseReleaseEvent(self, event):
        active = self.drag_offset is not None
        super().mouseReleaseEvent(event)
        if active:
            self.clamp_position()
            if not self.dragged:
                self.animate('happy', 90)
                self.say(random.choice(['Мурр ♡', 'Ще трішки!', 'Ти мій улюблений герой!']))
            else:
                self.animate('hop', 70)
                self.say('Приземлення успішне!')
        self.press_pos = None

    def cast_direction(self, direction):
        self.walk_direction = direction
        self.animate('cast', 120)

    def show_menu(self, at):
        menu = QMenu(self)
        actions = {}
        for title, state in [('Танцювати', 'dance'), ('Пострибати', 'hop'), ('Подрімати', 'sleep'), ('За курсором', 'chase'), ('Стріляти • вогняне крутіння', 'shoot'), ('Магія', 'cast')]:
            actions[menu.addAction(title)] = lambda s=state: self.animate(s, 180)
        actions[menu.addAction('Гача та Shiny Gallery')] = self.open_gallery
        directions = menu.addMenu('Напрям магії')
        for title, direction in [('Праворуч', 'right'), ('Вгору', 'up'), ('Вниз', 'down')]:
            actions[directions.addAction(title)] = lambda d=direction: self.cast_direction(d)
        events = menu.addMenu('Івенти Realm')
        for kind, title in EVENTS.items():
            actions[events.addAction(title)] = lambda k=kind: self.trigger_event(k)
        auto = menu.addAction('Випадкові івенти')
        auto.setCheckable(True)
        auto.setChecked(self.events_enabled)
        reduced = menu.addAction('Зменшений рух')
        reduced.setCheckable(True)
        reduced.setChecked(self.reduced_motion)
        pause = menu.addAction('Продовжити' if self.paused else 'Пауза')
        menu.addSeparator()
        count = menu.addAction(f'Зібрано луту: {self.loot_count}')
        count.setEnabled(False)
        quit_action = menu.addAction('Вийти')
        selected = menu.exec(at)
        if selected in actions:
            actions[selected]()
        elif selected == auto:
            self.events_enabled = auto.isChecked()
            self.settings.setValue('events', self.events_enabled)
            self.next_event = self.ticks + random.randint(600, 1350)
        elif selected == reduced:
            self.reduced_motion = reduced.isChecked()
            self.settings.setValue('reduced', self.reduced_motion)
        elif selected == pause:
            self.paused = not self.paused
        elif selected == quit_action:
            self.close()
        self.update()

if __name__ == '__main__':
    app = QApplication(sys.argv)
    try:
        pet = Umi()
    except (OSError, ValueError, KeyError, RuntimeError) as exc:
        QMessageBox.critical(None, 'Umi — помилка запуску',
                             'Не вдалося завантажити ресурси або колекцію.\n'
                             'Існуючі збереження не скинуто.\n'+str(exc))
        sys.exit(1)
    sys.exit(app.exec())
