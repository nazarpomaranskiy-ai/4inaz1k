"""A launcher exit code is not proof Python ran: emit a marker from Python itself."""
from pathlib import Path
import struct
import sys

def supported(version, bits):
    return (3,10) <= tuple(version[:2]) < (3,14) and bits == 64

def probe(destination):
    if not supported(sys.version_info, struct.calcsize('P')*8):
        print('Umi needs Python 3.10-3.13, 64-bit.', file=sys.stderr)
        return 1
    executable=Path(sys.executable)
    if not executable.is_file(): return 1
    Path(destination).write_text(str(executable),encoding='utf-8')
    return 0

if __name__=='__main__':
    sys.exit(probe(sys.argv[1]))
