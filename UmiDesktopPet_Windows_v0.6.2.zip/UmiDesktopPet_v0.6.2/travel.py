"""Short ground runs, surface tracking and time-based ballistic hops."""
import math
import random
from dataclasses import dataclass
from platforms import exposed_surfaces

@dataclass
class Jump:
    start: tuple
    target: object
    x: float
    age: int=0
    duration: int=27
    def position(self):
        t=min(1,self.age/self.duration)
        end=(self.x-105,self.target.top-174)
        return (self.start[0]+(end[0]-self.start[0])*t,
                self.start[1]+(end[1]-self.start[1])*t-4*min(130,55+abs(end[0]-self.start[0])*.12)*t*(1-t))

class Travel:
    def __init__(self, provider):
        self.provider=provider;self.surfaces=[];self.host=None;self.jump=None
        self.next_action=0;self.refresh_at=0;self.running=False;self.mode='rest'
        self.enabled=True
    def cancel(self):
        self.jump=None;self.running=False;self.mode='rest';self.host=None;self.next_action=0
    def refresh(self, pet):
        self.surfaces=exposed_surfaces(self.provider.windows(),pet.area)
        self.refresh_at=pet.ticks+15
    def nearest(self,pet):
        return min(self.surfaces,key=lambda s: abs(s.top-(pet.ypos+174))+abs(s.clamp(pet.xpos+105)-(pet.xpos+105))*.4)
    def start_jump(self,pet,target,x=None):
        self.running=False;self.mode='jump'
        self.jump=Jump((pet.xpos,pet.ypos),target,target.clamp(pet.xpos+105 if x is None else x))
        pet.facing=1 if self.jump.x>=pet.xpos+105 else -1
        self.provider.place_above_host(int(pet.winId()),target.handle)
    def step(self,pet):
        if not self.enabled:return
        if pet.ticks>=self.refresh_at or not self.surfaces:self.refresh(pet)
        if pet.reduced_motion:
            self.jump=None;self.running=False;self.mode='rest';return
        if self.jump:
            j=self.jump
            # Track a moved/resized target; redirect to the floor if it disappears.
            match=[s for s in self.surfaces if s.handle==j.target.handle]
            j.target=min(match,key=lambda s:abs(s.clamp(j.x)-j.x)) if match else self.surfaces[-1]
            j.x=j.target.clamp(j.x)
            j.age+=1;pet.xpos,pet.ypos=j.position()
            if j.age>=j.duration:
                self.host=j.target;self.jump=None;self.mode='rest';self.next_action=pet.ticks+random.randint(35,85)
                self.provider.place_above_host(int(pet.winId()),self.host.handle)
        else:
            match=[s for s in self.surfaces if self.host and s.handle==self.host.handle and s.left<=pet.xpos+105<=s.right]
            if not match:
                self.start_jump(pet,self.nearest(pet));return
            self.host=match[0]
            pet.ypos=self.host.top-174
            if pet.ticks%15==0:self.provider.place_above_host(int(pet.winId()),self.host.handle)
            if pet.ticks>=self.next_action and not pet.encounter:
                if self.running:
                    self.running=False;self.mode='rest';self.next_action=pet.ticks+random.randint(40,100)
                else:
                    targets=[s for s in self.surfaces if s.handle!=self.host.handle and abs(s.clamp(pet.xpos+105)-(pet.xpos+105))<900 and abs(s.top-self.host.top)<550]
                    if targets and random.random()<.6:self.start_jump(pet,random.choice(targets))
                    else:
                        self.running=True;self.mode='run';pet.facing=random.choice((-1,1));self.speed=random.uniform(4.5,7.5);self.next_action=pet.ticks+random.randint(18,42)
            if self.running and not pet.encounter:
                x=pet.xpos+105+pet.facing*self.speed
                if not self.host.left<=x<=self.host.right:
                    pet.facing*=-1;x=self.host.clamp(x)
                pet.xpos=x-105
        pet.move(round(pet.xpos),round(pet.ypos))
