import subprocess
import sys
import tempfile
from pathlib import Path
import unittest
from unittest.mock import patch
import runtime_probe

class RuntimeProbeTests(unittest.TestCase):
    def test_real_runtime_writes_executable_marker(self):
        with tempfile.TemporaryDirectory() as tmp:
            target=Path(tmp)/'runtime.txt'
            proc=subprocess.run([sys.executable,str(Path(runtime_probe.__file__)),str(target)],capture_output=True)
            self.assertEqual(proc.returncode,0,proc.stderr)
            self.assertEqual(Path(target.read_text(encoding='utf-8')),Path(sys.executable))
    def test_unsupported_runtime_never_writes_success_marker(self):
        for version,bits in [((3,9),64),((3,14),64),((3,12),32)]:
            with tempfile.TemporaryDirectory() as tmp:
                target=Path(tmp)/'runtime.txt'
                with patch.object(runtime_probe.sys,'version_info',version),patch.object(runtime_probe.struct,'calcsize',return_value=bits//8):
                    self.assertEqual(runtime_probe.probe(target),1)
                self.assertFalse(target.exists())
    def test_launcher_success_without_interpreter_has_no_marker(self):
        # Reproduce a launcher returning zero without ever executing the probe.
        with tempfile.TemporaryDirectory() as tmp:
            target=Path(tmp)/'runtime.txt'
            proc=subprocess.run([sys.executable,'-c','raise SystemExit(0)'])
            self.assertEqual(proc.returncode,0)
            self.assertFalse(target.exists())

if __name__=='__main__': unittest.main()
