import os
os.environ.setdefault('QT_QPA_PLATFORM','offscreen')
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch
from PySide6.QtWidgets import QApplication
from main import Umi
from platforms import WindowPlatforms
import bootstrap
app=QApplication.instance() or QApplication([])

class StartupTests(unittest.TestCase):
    def test_win32_initialization_failure_keeps_provider_usable(self):
        with patch('platforms.os.name','nt'), patch.object(WindowPlatforms,'_initialize_windows',side_effect=OSError('Missing DLL')):
            provider=WindowPlatforms()
        self.assertFalse(provider.enabled)
        self.assertIn('Missing DLL',provider.error)
        self.assertEqual(provider.windows(),[])
        provider.place_above_host(123,0)
    def test_recovery_has_visible_grace_period(self):
        p=Umi();p.timer.stop()
        self.assertGreater(p.recovery_until,p.ticks)
        with patch.object(p.travel,'step') as step:
            p.step();step.assert_not_called()
        p.hide();p.locate_pet()
        self.assertTrue(p.isVisible())
        self.assertTrue(p.area.contains(p.geometry()))
        p.close()
    def test_safe_mode_does_not_touch_saved_travel_preference(self):
        with patch('sys.argv',['bootstrap.py','--safe']):p=Umi()
        p.timer.stop();self.assertFalse(p.travel.enabled)
        self.assertTrue(p.safe_mode)
        p.close()
    def test_runtime_window_api_failure_recovers(self):
        p=Umi();p.timer.stop();p.travel.enabled=True;p.recovery_until=0
        with patch.object(p.travel,'step',side_effect=OSError('SetWindowPos failed')):
            p.step()
        self.assertFalse(p.travel.enabled)
        self.assertTrue(p.isVisible())
        self.assertGreater(p.recovery_until,p.ticks)
        p.close()
    def test_import_failure_logs_traceback_and_nonzero_exit(self):
        with tempfile.TemporaryDirectory() as tmp:
            fake=Path(tmp)/'main.py';fake.write_text('raise ImportError("missing Qt DLL")')
            import logging
            log=logging.getLogger('startup-test')
            handler=logging.FileHandler(Path(tmp)/'error.log');log.addHandler(handler)
            stream=open(Path(tmp)/'fault.log','a')
            with patch.object(bootstrap,'ROOT',Path(tmp)),patch.object(bootstrap,'install_diagnostics',return_value=(log,stream)):
                self.assertEqual(bootstrap.main(),1)
            handler.close();log.removeHandler(handler)
            self.assertIn('missing Qt DLL',(Path(tmp)/'error.log').read_text())

if __name__=='__main__':unittest.main()
