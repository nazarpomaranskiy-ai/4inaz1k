"""Procedural four-paw rig using the original boss head/tails and palette.
This is an adapted desktop gait, not a native game run animation.
"""
import math
from PySide6.QtCore import QRect
from PySide6.QtGui import QColor

def paint_run(p, frame, phase, airborne=False):
    p.save()
    p.translate(-62, 5)
    p.scale(5,5)
    p.setPen(QColor('#6a281c'))
    # Far paws swing opposite the near paws: four distinct limb anchors.
    for x,offset in ((8,math.pi),(18,0),(4,0),(14,math.pi)):
        swing=0 if airborne else round(math.sin(phase+offset))
        lift=2 if airborne else max(0,round(math.cos(phase+offset)*2))
        p.fillRect(x,4,2,4-lift,QColor('#b34b25'))
        p.fillRect(x+swing,7-lift,2,2,QColor('#f1d7a0'))
    p.fillRect(4,0,15,5,QColor('#b94a25'))
    p.fillRect(5,0,13,2,QColor('#ef8734'))
    p.fillRect(8,4,9,2,QColor('#ffe0a3'))
    # Preserve native head and tail pixels; only the body/leg rig is procedural.
    p.drawPixmap(QRect(-3,-4,10,13),frame,QRect(9,19,9,13))
    p.drawPixmap(QRect(14,-9,11,10),frame,QRect(16,16,11,9))
    p.restore()
