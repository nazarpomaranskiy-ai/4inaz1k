import math
import random
import sys
from pathlib import Path

from PySide6.QtCore import QPoint, QRect, Qt, QTimer
from PySide6.QtGui import QAction, QColor, QCursor, QPainter, QPixmap, QTransform
from PySide6.QtWidgets import QApplication, QMenu, QWidget

ROOT = Path(__file__).resolve().parent


class Umi(QWidget):
    def __init__(self):
        super().__init__()
        self.sprite = QPixmap(str(ROOT / 'assets' / 'umi.png'))
        if self.sprite.isNull():
            raise RuntimeError('Missing assets/umi.png')
        self.scale = 1.0
        self.sprite_size = 90
        self.setFixedSize(160, 170)
        self.setWindowFlags(Qt.WindowType.FramelessWindowHint | Qt.WindowType.WindowDoesNotAcceptFocus | Qt.WindowType.Tool)
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground)
        self.setAttribute(Qt.WidgetAttribute.WA_NoSystemBackground)
        self.setAttribute(Qt.WidgetAttribute.WA_ShowWithoutActivating)
        self.setMouseTracking(True)
        self.area = QApplication.primaryScreen().availableGeometry()
        self.xpos = float(self.area.center().x())
        self.ypos = float(self.area.bottom() - 200)
        self.dx = 2.0
        self.dy = 1.1
        self.facing = 1
        self.state = 'wander'
        self.ticks = 0
        self.state_until = 120
        self.drag_offset = None
        self.particles = []
        self.paused = False
        self.reduced_motion = False
        self.teleport_target = None
        self.teleport_phase = 0
        self.timer = QTimer(self)
        self.timer.timeout.connect(self.step)
        self.timer.start(33)
        self.move(round(self.xpos), round(self.ypos))
        self.show()

    def pick_state(self):
        self.state = random.choices(['wander', 'dance', 'rest', 'chase', 'teleport'], [42, 23, 10, 16, 9])[0]
        self.state_until = self.ticks + random.randint(55, 160)
        if self.state == 'wander':
            self.dx = random.choice([-1, 1]) * random.uniform(1.0, 3.2)
            self.dy = random.choice([-1, 1]) * random.uniform(.5, 2.2)
        elif self.state == 'teleport':
            self.teleport_target = (random.uniform(self.area.left(), max(self.area.left(), self.area.right() - self.width())), random.uniform(self.area.top(), max(self.area.top(), self.area.bottom() - self.height())))
            self.teleport_phase = 1

    def sparkle(self, n=7):
        for _ in range(n):
            self.particles.append([random.uniform(35, 125), random.uniform(30, 135), random.uniform(-2, 2), random.uniform(-2.5, .4), random.randint(14, 32)])

    def step(self):
        if self.paused or self.drag_offset is not None:
            return
        self.ticks += 1
        if self.ticks >= self.state_until and not self.teleport_phase:
            self.pick_state()
        if self.state == 'teleport' and self.teleport_phase:
            self.teleport_phase += 1
            if self.teleport_phase == 10:
                self.sparkle(18)
                self.xpos, self.ypos = self.teleport_target
                self.move(round(self.xpos), round(self.ypos))
            if self.teleport_phase >= 20:
                self.teleport_phase = 0
                self.state_until = self.ticks + 35
        elif self.state in ('wander', 'chase'):
            if self.state == 'chase':
                c = QCursor.pos()
                vx = c.x() - (self.xpos + 80)
                vy = c.y() - (self.ypos + 85)
                distance = max(1, math.hypot(vx, vy))
                if distance > 75:
                    self.dx = vx / distance * 3.3
                    self.dy = vy / distance * 3.3
                else:
                    self.dx *= .8
                    self.dy *= .8
            self.xpos += self.dx
            self.ypos += self.dy
            self.facing = 1 if self.dx >= 0 else -1
            left, top = self.area.left(), self.area.top()
            right = max(left, self.area.right() - self.width())
            bottom = max(top, self.area.bottom() - self.height())
            if self.xpos <= left or self.xpos >= right:
                self.dx = -self.dx
                self.xpos = min(right, max(left, self.xpos))
            if self.ypos <= top or self.ypos >= bottom:
                self.dy = -self.dy
                self.ypos = min(bottom, max(top, self.ypos))
            self.move(round(self.xpos), round(self.ypos))
        if self.state == 'dance' and self.ticks % 11 == 0:
            self.sparkle(2)
        for p in self.particles:
            p[0] += p[2]
            p[1] += p[3]
            p[4] -= 1
        self.particles = [p for p in self.particles if p[4] > 0]
        self.update()

    def paintEvent(self, event):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.SmoothPixmapTransform, False)
        center_x, center_y = 80, 82
        bob = 0 if self.reduced_motion else (math.sin(self.ticks * .22) * (5 if self.state == 'dance' else 2))
        angle = 0 if self.reduced_motion else (math.sin(self.ticks * .16) * 10 if self.state == 'dance' else 0)
        zoom = 1 if self.reduced_motion else (1 + .045 * math.sin(self.ticks * .2) if self.state == 'dance' else 1)
        opacity = 1
        if self.teleport_phase:
            opacity = max(.05, abs(self.teleport_phase - 10) / 10)
        painter.setOpacity(opacity)
        painter.translate(center_x, center_y + bob)
        painter.rotate(angle)
        painter.scale(self.facing * zoom * self.scale, zoom * self.scale)
        painter.drawPixmap(-45, -45, self.sprite)
        painter.resetTransform()
        painter.setOpacity(1)
        for x, y, _, _, life in self.particles:
            color = QColor(255, 200, 90, min(255, life * 9))
            painter.fillRect(QRect(round(x), round(y), 3, 3), color)

    def mousePressEvent(self, event):
        if event.button() == Qt.MouseButton.LeftButton:
            self.drag_offset = event.globalPosition().toPoint() - self.pos()
            self.state = 'rest'
            self.update()
        elif event.button() == Qt.MouseButton.RightButton:
            self.show_menu(event.globalPosition().toPoint())

    def mouseMoveEvent(self, event):
        if self.drag_offset is not None:
            pos = event.globalPosition().toPoint() - self.drag_offset
            self.xpos, self.ypos = pos.x(), pos.y()
            self.move(pos)

    def mouseReleaseEvent(self, event):
        if event.button() == Qt.MouseButton.LeftButton and self.drag_offset is not None:
            self.drag_offset = None
            self.state_until = self.ticks + 30
            self.sparkle(8)

    def mouseDoubleClickEvent(self, event):
        if event.button() == Qt.MouseButton.LeftButton:
            self.state = 'dance'
            self.state_until = self.ticks + 140
            self.sparkle(10)

    def show_menu(self, at):
        menu = QMenu(self)
        dance = menu.addAction('Dance!')
        teleport = menu.addAction('Teleport')
        pause = menu.addAction('Resume' if self.paused else 'Pause')
        reduced = menu.addAction('Reduced motion')
        reduced.setCheckable(True)
        reduced.setChecked(self.reduced_motion)
        menu.addSeparator()
        quit_action = menu.addAction('Quit')
        selected = menu.exec(at)
        if selected == dance:
            self.state, self.state_until = 'dance', self.ticks + 140
        elif selected == teleport:
            self.state = 'teleport'
            self.teleport_target = (random.uniform(self.area.left(), max(self.area.left(), self.area.right() - self.width())), random.uniform(self.area.top(), max(self.area.top(), self.area.bottom() - self.height())))
            self.teleport_phase = 1
        elif selected == pause:
            self.paused = not self.paused
        elif selected == reduced:
            self.reduced_motion = reduced.isChecked()
        elif selected == quit_action:
            QApplication.quit()


if __name__ == '__main__':
    app = QApplication(sys.argv)
    app.setQuitOnLastWindowClosed(True)
    pet = Umi()
    sys.exit(app.exec())
