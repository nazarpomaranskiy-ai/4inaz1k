@echo off
setlocal
chcp 65001 >nul
cd /d "%~dp0"
set "UMI_LOG=%~dp0startup.log"
set "UMI_PROBE=%TEMP%\umi-runtime-%RANDOM%-%RANDOM%.txt"
set "UMI_PY="
> "%UMI_LOG%" echo Umi 0.6.2 startup
if not exist bootstrap.py goto missing_files
if not exist runtime_probe.py goto missing_files
if not exist main.py goto missing_files
if not exist assets\boss.png goto missing_files
echo Looking for a working Python installation...
if not exist ".venv-061\Scripts\python.exe" goto find_python
call :clear_probe
".venv-061\Scripts\python.exe" runtime_probe.py "%UMI_PROBE%" >>"%UMI_LOG%" 2>&1
call :read_probe
if defined UMI_PY goto dependencies
:find_python
for %%V in (3.13 3.12 3.11 3.10) do call :try_py %%V
if defined UMI_PY goto create_env
call :clear_probe
python runtime_probe.py "%UMI_PROBE%" >>"%UMI_LOG%" 2>&1
call :read_probe
if not defined UMI_PY goto no_python
:create_env
echo Creating Python environment. Please wait...
"%UMI_PY%" -m venv ".venv-061" >>"%UMI_LOG%" 2>&1
if errorlevel 1 goto failed
if not exist ".venv-061\Scripts\python.exe" goto missing_env
call :clear_probe
".venv-061\Scripts\python.exe" runtime_probe.py "%UMI_PROBE%" >>"%UMI_LOG%" 2>&1
set "UMI_PY="
call :read_probe
if not defined UMI_PY goto missing_env
:dependencies
echo Checking dependencies...
".venv-061\Scripts\python.exe" -c "from PySide6.QtWidgets import QApplication" >>"%UMI_LOG%" 2>&1
if not errorlevel 1 goto run_pet
echo Installing PySide6. First launch requires Internet and may take a few minutes.
".venv-061\Scripts\python.exe" -m pip install -r requirements.txt >>"%UMI_LOG%" 2>&1
if errorlevel 1 goto failed
:run_pet
echo Starting Umi. Keep this window open while Umi is running.
echo If Umi is hidden, use the Umi icon near the Windows clock.
".venv-061\Scripts\python.exe" -u bootstrap.py %* >>"%UMI_LOG%" 2>&1
if errorlevel 1 goto failed
exit /b 0
:try_py
if defined UMI_PY exit /b 0
call :clear_probe
py -%1 runtime_probe.py "%UMI_PROBE%" >>"%UMI_LOG%" 2>&1
call :read_probe
exit /b 0
:clear_probe
if exist "%UMI_PROBE%" del /q "%UMI_PROBE%"
exit /b 0
:read_probe
if not exist "%UMI_PROBE%" exit /b 0
set /p "UMI_PY=" < "%UMI_PROBE%"
del /q "%UMI_PROBE%"
if not exist "%UMI_PY%" set "UMI_PY="
exit /b 0
:missing_files
echo Extract the ENTIRE ZIP into a regular folder first.
echo Run start.bat from that folder, not from inside the ZIP.
goto failed
:missing_env
echo Python did not create a working virtual environment. >>"%UMI_LOG%"
goto failed
:no_python
echo No working Python 3.10-3.13 64-bit runtime was found. >>"%UMI_LOG%"
echo Install Python 3.12 64-bit from https://www.python.org/downloads/windows/ >>"%UMI_LOG%"
echo If you use Python Install Manager, run: py install 3.12 >>"%UMI_LOG%"
echo Then run start.bat again. >>"%UMI_LOG%"
goto failed
:failed
call :clear_probe
echo.
echo Umi could not start. Details below:
type "%UMI_LOG%"
echo.
echo Send startup.log and umi-error.log from this folder if the issue continues.
pause
exit /b 1
