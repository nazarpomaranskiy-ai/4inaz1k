import os
os.environ.setdefault('QT_QPA_PLATFORM','offscreen')
import tempfile
import copy
import unittest
from unittest.mock import patch
from PySide6.QtCore import QRect,QSettings,Qt,QPoint
from PySide6.QtTest import QTest
from PySide6.QtWidgets import QApplication
from main import Umi
from gacha import Collection
from platforms import Surface,exposed_surfaces
from travel import Travel
from test_gacha import FixedRandom
app=QApplication.instance() or QApplication([])

class FakeWindows:
    def __init__(self):self.rects=[(11,QRect(130,350,420,250)),(22,QRect(590,470,400,200))];self.placed=[]
    def windows(self):return self.rects
    def place_above_host(self,pet,host):self.placed.append(host)

class V06Tests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.settings=QSettings(self.tmp.name+'/test.ini',QSettings.Format.IniFormat)
        self.pet=Umi();self.pet.timer.stop();self.pet.events_enabled=False;self.pet.reduced_motion=False
        self.provider=FakeWindows();self.pet.travel=Travel(self.provider)
        self.pet.area=QRect(0,0,1280,900);self.pet.xpos=200;self.pet.ypos=176
        self.pet.travel.refresh(self.pet)
        self.pet.travel.host=self.pet.travel.surfaces[0];self.pet.travel.next_action=10000
        self.pet.collection=Collection(self.settings)
    def tearDown(self):self.pet.close();self.tmp.cleanup()
    def test_occlusion_edges(self):
        windows=[(1,QRect(250,250,250,300)),(2,QRect(100,350,600,300))]
        surfaces=exposed_surfaces(windows,QRect(0,0,1280,900))
        for s in surfaces:
            if s.handle==2:self.assertFalse(s.left<400<s.right)
        self.assertTrue(any(s.handle==2 for s in surfaces))
    def test_jump_arc_and_landing(self):
        t=self.pet.travel;target=next(s for s in t.surfaces if s.handle==22)
        t.start_jump(self.pet,target,720)
        start=self.pet.ypos
        for _ in range(13):self.pet.step()
        self.assertLess(self.pet.ypos,(start+(target.top-174))/2)
        for _ in range(14):self.pet.step()
        self.assertIsNone(t.jump);self.assertEqual(t.host.handle,22)
        self.assertEqual((self.pet.xpos,self.pet.ypos),(615,296))
        self.assertIn(22,self.provider.placed)
    def test_closed_destination_redirects_to_floor(self):
        t=self.pet.travel;t.start_jump(self.pet,t.surfaces[1],720)
        self.provider.rects=[];t.refresh(self.pet)
        for _ in range(27):self.pet.step()
        self.assertEqual(t.host.handle,0);self.assertEqual(self.pet.ypos,669)
    def test_support_moves_and_disappears(self):
        t=self.pet.travel
        self.provider.rects[0]=(11,QRect(130,400,420,250));t.refresh(self.pet);self.pet.step()
        self.assertEqual(self.pet.ypos,226)
        self.provider.rects=[];t.refresh(self.pet);self.pet.step()
        self.assertIsNotNone(t.jump)
    def test_run_is_bounded_and_has_pause(self):
        t=self.pet.travel;t.running=True;t.mode='run';t.speed=7;t.next_action=self.pet.ticks+20
        self.pet.facing=1;seen=set()
        for _ in range(20):
            self.pet.step();seen.add(int(self.pet.walk_phase));self.assertLessEqual(self.pet.xpos+105,t.host.right)
        self.assertFalse(t.running);self.assertGreater(t.next_action,self.pet.ticks)
        self.assertGreater(len(seen),1)
    def test_pause_and_reduced_motion_stop_jump(self):
        t=self.pet.travel;t.start_jump(self.pet,t.surfaces[1],720)
        before=(self.pet.xpos,self.pet.ypos);self.pet.paused=True
        self.pet.step();self.assertEqual((self.pet.xpos,self.pet.ypos),before);self.assertEqual(t.jump.age,0)
        self.pet.paused=False;self.pet.reduced_motion=True;self.pet.step()
        self.assertIsNone(t.jump);self.assertEqual((self.pet.xpos,self.pet.ypos),before)
    def test_gift_each_color_free_and_persistent(self):
        for r,color in ((0,'cyan'),(.65,'red'),(.92,'white')):
            c=Collection(self.settings,FixedRandom([r,1]));before=(c.data['tokens'],c.data['rolls'],c.data['white_misses'])
            result=c.gift();self.assertEqual(result['bag'],color);self.assertEqual(len(result['drops']),1)
            restored=Collection(self.settings)
            self.assertEqual((restored.data['tokens'],restored.data['rolls'],restored.data['white_misses']),before)
            self.assertEqual(restored.data['history'][-1]['source'],'gift')
    def test_gift_event_is_once_and_click_does_not_charge(self):
        self.pet.collection.rng=FixedRandom([.95,1]);self.pet.trigger_event('gift')
        self.assertEqual(self.pet.encounter,'gift');self.assertEqual(self.pet.gift_result['bag'],'white')
        self.pet.trigger_event('gift');self.assertEqual(len(self.pet.collection.data['history']),1)
        QTest.mouseClick(self.pet,Qt.MouseButton.LeftButton,pos=QPoint(185,145))
        self.assertIsNone(self.pet.encounter);self.assertEqual(self.pet.collection.data['tokens'],5)
        self.assertEqual(len(self.pet.collection.data['history']),1)
        self.pet.gallery.close()
    def test_gift_failure_rolls_back(self):
        c=self.pet.collection;before=copy.deepcopy(c.data)
        with patch.object(c,'save',side_effect=OSError('full')):
            with self.assertRaises(OSError):c.gift('cyan')
        self.assertEqual(c.data,before)
    def test_no_global_topmost_flag(self):
        self.assertFalse(self.pet.windowFlags() & Qt.WindowType.WindowStaysOnTopHint)

if __name__=='__main__':unittest.main()
