"""Read-only Win32 window geometry and non-activating pet Z-order placement."""
import ctypes
import os
from dataclasses import dataclass
from PySide6.QtCore import QRect
from PySide6.QtWidgets import QApplication

@dataclass(frozen=True)
class Surface:
    handle: int
    left: float
    right: float
    top: float
    def clamp(self, x): return min(self.right, max(self.left, x))


def exposed_surfaces(windows, area, foot=174, width=240, anchor=105):
    """Windows arrive front to back; subtract occluding rectangles from each edge."""
    out=[]
    for i,(handle,rect) in enumerate(windows):
        y=rect.top()
        if not area.top()+foot <= y <= area.bottom()-(230-foot): continue
        spans=[(max(rect.left(),area.left()), min(rect.right(),area.right()))]
        for _,cover in windows[:i]:
            if cover.top() <= y+2 <= cover.bottom():
                remaining=[]
                for a,b in spans:
                    if cover.right()<a or cover.left()>b: remaining.append((a,b))
                    else:
                        if cover.left()>a: remaining.append((a,cover.left()))
                        if cover.right()<b: remaining.append((cover.right(),b))
                spans=remaining
        for a,b in spans:
            # Leave room for the body on the window and the entire widget on screen.
            left=max(a+40,area.left()+anchor)
            right=min(b-40,area.right()-(width-anchor))
            if right-left>=24: out.append(Surface(handle,left,right,y))
    out.append(Surface(0,area.left()+anchor,max(area.left()+anchor,area.right()-(width-anchor)),area.bottom()-(230-foot)))
    return out

class WindowPlatforms:
    def __init__(self):
        self.floor_anchor=0
        self.enabled=os.name=='nt'
        if not self.enabled:return
        from ctypes import wintypes as w
        self.w=w;self.user=ctypes.WinDLL('user32',use_last_error=True)
        self.dwm=ctypes.WinDLL('dwmapi')
        self.callback=ctypes.WINFUNCTYPE(w.BOOL,w.HWND,w.LPARAM)
        u=self.user
        u.EnumWindows.argtypes=[self.callback,w.LPARAM];u.EnumWindows.restype=w.BOOL
        for name in ('IsWindowVisible','IsIconic'):
            getattr(u,name).argtypes=[w.HWND];getattr(u,name).restype=w.BOOL
        u.GetWindowRect.argtypes=[w.HWND,ctypes.POINTER(w.RECT)]
        u.GetWindowThreadProcessId.argtypes=[w.HWND,ctypes.POINTER(w.DWORD)]
        u.GetClassNameW.argtypes=[w.HWND,w.LPWSTR,ctypes.c_int]
        u.GetWindowLongW.argtypes=[w.HWND,ctypes.c_int];u.GetWindowLongW.restype=ctypes.c_long
        u.GetWindow.argtypes=[w.HWND,w.UINT];u.GetWindow.restype=w.HWND
        u.SetWindowPos.argtypes=[w.HWND,w.HWND,ctypes.c_int,ctypes.c_int,ctypes.c_int,ctypes.c_int,w.UINT]
        u.SetWindowPos.restype=w.BOOL
        u.MonitorFromWindow.argtypes=[w.HWND,w.DWORD];u.MonitorFromWindow.restype=w.HANDLE
        class MonitorInfo(ctypes.Structure):
            _fields_=[('cbSize',w.DWORD),('rcMonitor',w.RECT),('rcWork',w.RECT),('dwFlags',w.DWORD),('szDevice',w.WCHAR*32)]
        self.MonitorInfo=MonitorInfo
        u.GetMonitorInfoW.argtypes=[w.HANDLE,ctypes.POINTER(MonitorInfo)]
        self.dwm.DwmGetWindowAttribute.argtypes=[w.HWND,w.DWORD,ctypes.c_void_p,w.DWORD]

    def windows(self):
        if not self.enabled:return []
        w,u=self.w,self.user;out=[]
        def visit(hwnd,_):
            if not u.IsWindowVisible(hwnd) or u.IsIconic(hwnd):return True
            pid=w.DWORD();u.GetWindowThreadProcessId(hwnd,ctypes.byref(pid))
            if pid.value==os.getpid():return True
            cls=ctypes.create_unicode_buffer(256);u.GetClassNameW(hwnd,cls,256)
            if cls.value in ('Progman','WorkerW','Shell_TrayWnd','Shell_SecondaryTrayWnd'):return True
            cloaked=w.DWORD()
            if self.dwm.DwmGetWindowAttribute(hwnd,14,ctypes.byref(cloaked),ctypes.sizeof(cloaked))==0 and cloaked.value:return True
            r=w.RECT()
            if self.dwm.DwmGetWindowAttribute(hwnd,9,ctypes.byref(r),ctypes.sizeof(r))!=0:
                if not u.GetWindowRect(hwnd,ctypes.byref(r)):return True
            if r.right-r.left<100 or r.bottom-r.top<60:return True
            mi=self.MonitorInfo();mi.cbSize=ctypes.sizeof(mi)
            if not u.GetMonitorInfoW(u.MonitorFromWindow(hwnd,2),ctypes.byref(mi)):return True
            screen=next((s for s in QApplication.screens() if s.name()==mi.szDevice),None)
            if screen is None:screen=QApplication.primaryScreen()
            q=screen.geometry();scale=q.width()/max(1,mi.rcMonitor.right-mi.rcMonitor.left)
            x=q.left()+(r.left-mi.rcMonitor.left)*scale;y=q.top()+(r.top-mi.rcMonitor.top)*scale
            out.append((int(hwnd),QRect(round(x),round(y),round((r.right-r.left)*scale),round((r.bottom-r.top)*scale))))
            return True
        callback=self.callback(visit);u.EnumWindows(callback,0)
        self.floor_anchor=out[-1][0] if out else 0
        return out

    def place_above_host(self, pet_handle, host):
        if not self.enabled:return
        # Never activate another application, move it, or make Umi globally topmost.
        u=self.user
        if host:
            previous=u.GetWindow(host,3)  # GW_HWNDPREV
            if previous==pet_handle: previous=u.GetWindow(previous,3)
            insert=previous or 0
            if insert and u.GetWindowLongW(insert,-20)&0x00000008: insert=0
        else:
            insert=self.floor_anchor  # Below applications, above the shell desktop.
        u.SetWindowPos(pet_handle,insert,0,0,0,0,0x0010|0x0001|0x0002)
