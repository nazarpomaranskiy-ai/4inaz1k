import os
os.environ.setdefault('QT_QPA_PLATFORM', 'offscreen')
import unittest
from PySide6.QtCore import QPoint, Qt, QSettings
from PySide6.QtTest import QTest
from PySide6.QtWidgets import QApplication
from main import Umi, EVENTS

app = QApplication.instance() or QApplication([])
QSettings.setDefaultFormat(QSettings.Format.IniFormat)
QSettings.setPath(QSettings.Format.NativeFormat, QSettings.Scope.UserScope, '/tmp/umi-test-settings')

class PetTests(unittest.TestCase):
    def setUp(self):
        self.pet = Umi()
        self.pet.timer.stop()
        self.pet.events_enabled = False
        self.pet.reduced_motion = False
    def tearDown(self):
        self.pet.close()
    def test_all_states_render(self):
        for state in ['wander', 'chase', 'dance', 'sleep', 'hop', 'happy', 'look']:
            self.pet.animate(state)
            self.pet.step()
            self.assertFalse(self.pet.grab().isNull())
        for kind in EVENTS:
            self.pet.trigger_event(kind)
            self.pet.step()
            self.assertFalse(self.pet.grab().isNull())
    def test_slime_drops_collectible_loot(self):
        self.pet.trigger_event('slime')
        for _ in range(150): self.pet.step()
        self.assertEqual(self.pet.encounter, 'loot')
        count = self.pet.loot_count
        QTest.mouseClick(self.pet, Qt.MouseButton.LeftButton, pos=QPoint(188, 153))
        self.assertEqual(self.pet.loot_count, count+1)
        self.assertIsNone(self.pet.encounter)
    def test_pause_freezes_event(self):
        self.pet.trigger_event('meteor')
        self.pet.paused = True
        before = (self.pet.ticks, self.pet.event_age)
        for _ in range(30): self.pet.step()
        self.assertEqual(before, (self.pet.ticks, self.pet.event_age))
    def test_reduced_motion_and_expiry(self):
        self.pet.reduced_motion = True
        self.pet.animate('wander')
        before = self.pet.pos()
        for _ in range(40): self.pet.step()
        self.assertEqual(self.pet.pos(), before)
        self.pet.trigger_event('portal')
        for _ in range(240): self.pet.step()
        self.assertIsNone(self.pet.encounter)
    def test_pet_and_drag(self):
        QTest.mouseClick(self.pet, Qt.MouseButton.LeftButton, pos=QPoint(100, 120))
        self.assertEqual(self.pet.state, 'happy')
        QTest.mousePress(self.pet, Qt.MouseButton.LeftButton, pos=QPoint(100, 120))
        QTest.mouseMove(self.pet, QPoint(130, 140))
        QTest.mouseRelease(self.pet, Qt.MouseButton.LeftButton, pos=QPoint(130, 140))
        self.assertIsNone(self.pet.drag_offset)
        self.assertEqual(self.pet.state, 'hop')
    def test_automatic_event(self):
        self.pet.events_enabled = True
        self.pet.next_event = self.pet.ticks+1
        self.pet.step()
        self.assertIn(self.pet.encounter, EVENTS)

if __name__ == '__main__': unittest.main()
