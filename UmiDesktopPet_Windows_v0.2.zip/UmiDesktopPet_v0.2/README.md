# Umi Desktop Pet 0.2 — Realm-inspired update

## Windows
Install Python 3.10+ with the Windows Python launcher (`py`), extract this folder,
and double-click `start.bat`. First launch creates a local `.venv` and installs
PySide6 (Internet required). Later launches reuse it. This package contains source,
not a compiled EXE. Keep `main.py`, `base_pet.py` and `assets` together.

## Controls
- Click Umi: pet her, with hearts and a happy bounce.
- Drag: reposition; release to land with a hop. Bounds use the drop monitor.
- Double-click: dance.
- Right-click: dance, jump, sleep, follow the cursor, trigger an event, pause,
  toggle random events or reduced motion, quit.
- Click the white bag during a loot event to collect it.

## What's new
Procedural walking sway, jump arcs, squash/stretch, breathing sleep with Zs,
hearts, speech bubbles and landing reactions. Hover over sleeping Umi to wake her.
Random events occur after 20–45 seconds of active time, with an initial 20–40
second delay: Nexus-style portal, mini-slime fight that drops a white bag,
meteor shower, or collectible loot. Events expire after eight seconds; slime
combat lasts five seconds before the eight-second loot phase.
Settings and collected loot persist through Qt's per-user settings (Windows
registry under UmiDesktop/Companion). Pausing freezes simulation and event timers.
Reduced motion stops autonomous travel and decorative transformations/particles;
manual dragging remains available. No real game accounts, items or files are used.

The supplied single sprite is preserved. Animations and event graphics are
procedurally drawn, inspired by Realm of the Mad God Exalt; no official game
animation sheets are included. The portal is a visual event, not a game connection.

## Limitations and validation
The transparent widget has a rectangular 240x230 mouse area. It can block clicks
near Umi; drag her away or quit using the menu. No interaction with other app
windows, no system-wide clicks, and no game integration. Movement stays on the
current monitor; drag to another monitor to change it.
Automated offscreen Qt checks cover painting, event transitions, collection,
pause, reduced motion, and dragging. Native Windows transparency, DPI behavior,
and the batch launcher still require a Windows machine for validation.
