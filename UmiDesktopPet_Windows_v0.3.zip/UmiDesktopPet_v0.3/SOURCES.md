# Sprite source and credits

Realm of the Mad God Exalt / Umi character artwork belongs to its respective
creators and DECA Games. This is an unofficial fan companion, not an official
DECA product. No ownership of the game artwork is claimed.

Public atlas mirror: https://github.com/liamt19/rotmg-dps-calculator-assets
Source revision: dd9f4082d2fb427d07b44fe27450c948ec27078b
- https://github.com/liamt19/rotmg-dps-calculator-assets/blob/dd9f4082d2fb427d07b44fe27450c948ec27078b/assets/characters.png
- https://github.com/liamt19/rotmg-dps-calculator-assets/blob/dd9f4082d2fb427d07b44fe27450c948ec27078b/assets/spritesheet.json

Selected metadata: moonlightVillageChars32x32, index 0, set 0.
Action 1, directions 0 (side), 2 (back), 3 (front): four frames each.
Action 0, direction 0: idle frame. Left is mirrored from the side frames.
Cells were extracted without redrawing and uniformly cropped from 32x32 to
17x16 using their common nontransparent bounds. The application uses integer
5x scaling without image smoothing. Frame timing is adapted for desktop travel;
it is not measured from gameplay footage. No video was downloaded or analyzed.

Original prototype sprite: provided by the user in UmiDesktopPet_Windows.zip.
